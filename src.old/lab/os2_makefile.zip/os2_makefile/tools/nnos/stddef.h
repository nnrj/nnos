#if (!defined(STDDEF_H))

#define STDDEF_H	1

#if (defined(__cplusplus))
	extern "C" {
#endif

typedef unsigned int size_t;

#if (defined(__cplusplus))
	}
#endif

#endif
