void NNOSMain(void)

void NNOSStarup(void){

    /*若想在NNOSMain之前做一些事情，请在此添加*/

    NNOSMain();

    /*若想在NNOSMain之后做一些事情，请在此添加*/

    return;
}