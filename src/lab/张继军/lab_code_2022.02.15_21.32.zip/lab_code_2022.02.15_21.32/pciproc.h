#ifndef __PCIPROC_H_
#define __PCIPROC_H_
typedef unsigned char BYTE;
typedef unsigned int  WORD;
typedef unsigned long DWORD;
/* PCI设备索引。bus/dev/func 共16位，为了方便处理可放在一个WORD中 */
#define PDI_BUS_SHIFT        8
#define PDI_BUS_SIZE         8
#define PDI_BUS_MAX          0xFF
#define PDI_BUS_MASK         0xFF00
#define PDI_DEVICE_SHIFT     3
#define PDI_DEVICE_SIZE      5
#define PDI_DEVICE_MAX       0x1F
#define PDI_DEVICE_MASK      0x00F8
#define PDI_FUNCTION_SHIFT   0
#define PDI_FUNCTION_SIZE    3
#define PDI_FUNCTION_MAX     0x7
#define PDI_FUNCTION_MASK    0x0007
#define MK_PDI(bus,dev,func) (WORD)((bus&PDI_BUS_MAX)<<PDI_BUS_SHIFT | (dev&PDI_DEVICE_MAX)<<PDI_DEVICE_SHIFT | (func&PDI_FUNCTION_MAX) )
/* PCI配置空间寄存器 */
#define PCI_CONFIG_ADDRESS   0xCF8
#define PCI_CONFIG_DATA      0xCFC
/* 填充PCI_CONFIG_ADDRESS */
#define MK_PCICFGADDR(bus,dev,func) (DWORD)(0x80000000L | (DWORD)MK_PDI(bus,dev,func) << 8)
unsigned short  pciConfigReadWord(unsigned char bus, unsigned char slot, unsigned char func, unsigned char offset);
unsigned short  getVendorID(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getDeviceID(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getClassId(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getSubClassId(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getBar4Address(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getbmcbase();
void pciideproc();



#endif
