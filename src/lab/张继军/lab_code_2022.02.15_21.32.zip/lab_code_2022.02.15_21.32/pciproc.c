#include "pciproc.h"

unsigned short  pciConfigReadWord(unsigned char bus, unsigned char slot, unsigned char func, unsigned char offset) {
    unsigned int address;
    unsigned int lbus  = (unsigned int)bus;
    unsigned int lslot = (unsigned int)slot;
    unsigned int lfunc = (unsigned int)func;
    unsigned short tmp = 0;
 
    // Create configuration address as per Figure 1
    address = (unsigned int)((lbus << 16) | (lslot << 11) |
              (lfunc << 8) | (offset & 0xFC) | ((unsigned int)0x80000000));
    
    // Write out the address
    out32(0xCF8, address);
    // Read in the data
    // (offset & 2) * 8) = 0 will choose the first word of the 32-bit register
    tmp = (unsigned short)((inl(0xCFC) >> ((offset & 2) * 8)) & 0xFFFF);	
    return tmp;
}
unsigned short getVendorID(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0);
        return r0;
}

unsigned short getDeviceID(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,2);
        return r0;
}

unsigned short getClassId(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0xA);
        return (r0 & ~0x00FF) >> 8;
}

unsigned short getSubClassId(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0xA);
        return (r0 & ~0xFF00);
}

unsigned short getBar4Address(unsigned short bus, unsigned short device, unsigned short function)
{
	unsigned int r0 = pciConfigReadWord(bus,device,function,0x20);
	//return (r0 & ~0x00E7) ;
	return r0;
}

unsigned short getbmcbase()
{
	int bus,dev,func;
	unsigned int dwAddr;
	unsigned int dwData;
	unsigned int tmpData;
	unsigned short bar4;
	unsigned short a;
	for(bus = 0; bus <= PDI_BUS_MAX; ++bus)
    {
        for(dev = 0; dev <= PDI_DEVICE_MAX; ++dev)
        {
            for(func = 0; func <= PDI_FUNCTION_MAX; ++func)
            {
                /* 计算地址 */
                dwAddr = MK_PCICFGADDR(bus, dev, func);
				/* 得到ClassID */
				tmpData = getClassId(bus,dev,func);								
				if ((unsigned int)tmpData==0x01){						
                /* 获取厂商ID */  	
                outl(PCI_CONFIG_ADDRESS, dwAddr);
                dwData = inl(PCI_CONFIG_DATA);                	
                /* 判断设备是否存在。FFFFh是非法厂商ID */
                if ((unsigned int)dwData != 0xFFFFFFFF)
                {
					
					bar4 = getBar4Address(bus,dev,func);
					if (bar4&0x01==1){
					 a = bar4-1;
					}
				}
			}				
		}	
	}	return a;	
}
}
void pciideproc()/* 枚举PCI IDE设备 */
{
    int bus, dev, func;
    int i;
    unsigned int dwAddr;
    unsigned int dwData;
    unsigned int tmpData;
	unsigned short BarA;
	char s[256];
    FILE* hF;
    char szFile[0x10];
    printf("\n");
    printf("Bus#\tDevice#\tFunc#\tVendor\t        Device\tClass\tIRQ\tIntPin\n");
    /* 枚举PCI设备 */	
    for(bus = 0; bus <= PDI_BUS_MAX; ++bus)
    {
        for(dev = 0; dev <= PDI_DEVICE_MAX; ++dev)
        {
            for(func = 0; func <= PDI_FUNCTION_MAX; ++func)
            {
                /* 计算地址 */
                dwAddr = MK_PCICFGADDR(bus, dev, func);
				/* 得到ClassID */
				tmpData = getClassId(bus,dev,func);								
				if ((unsigned int)tmpData==0x01){/*去掉这个判断就是取得所有有效PCI控制器的代码*/						
                /* 获取厂商ID */  	
                outl(PCI_CONFIG_ADDRESS, dwAddr);
                dwData = inl(PCI_CONFIG_DATA);                	
                /* 判断设备是否存在。FFFFh是非法厂商ID */
                if ((unsigned int)dwData != 0xFFFFFFFF)
                {
                    /* bus/dev/func */
                    printf("%2.2X\t%2.2X\t%1X\t", bus, dev, func);
                    /* Vendor/Device */
                    printf("%4.4X\t%4.4X\t", (unsigned int)dwData, dwData>>16);
                    /* Class Code */
                    outl(PCI_CONFIG_ADDRESS, dwAddr | 0x8);
                    dwData = inl(PCI_CONFIG_DATA);
                    printf("%6.6lX\t", dwData>>8);	                                 						
                    /* IRQ/intPin */
                    {
						outl(PCI_CONFIG_ADDRESS, dwAddr | 0x3C);
                        dwData = inl(PCI_CONFIG_DATA);
                        printf("%d\t", (unsigned char)dwData);
                        printf("%d", (unsigned char)(dwData>>8));
                        printf("\n");
						BarA = getBar4Address(bus,dev,func);
						if (BarA&0x01==1)// 判断bar4地址的最后一位如果是1表示是IDE设备，如果是0表示SCSI设备，2表示是软驱
						printf("%4.4X\t",BarA-1);
                    /* 写文件 */
					    sprintf(szFile, "PCI%2.2X%2.2X%X.bin", bus, dev, func);
                        hF = fopen(szFile, "wb");
                        if (hF != NULL)
						{
                        /* 256字节的PCI配置空间 */
                        //for (i = 0; i < 0x100; i += 4)
						for (i=0; i< 0x100; i += 4)	
                        {
                            /* Read */
                            outl(PCI_CONFIG_ADDRESS, dwAddr | i);
                            dwData = inl(PCI_CONFIG_DATA);								
                            /* Write */
                            fwrite(&dwData, sizeof(dwData), 1, hF);
                        }
                        fclose(hF);
						}
					}
                    }
                }
            }
			
        }
    }
    return ;
}
/* 程序结束 */

/* pciproc.c */
		
