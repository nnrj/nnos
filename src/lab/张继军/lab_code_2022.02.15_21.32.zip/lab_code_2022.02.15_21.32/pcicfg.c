#include <stdio.h>
#include "naskfunc.h"
/* 读取PCI配置空间所需要的变量的宏定义 */
typedef unsigned char BYTE;
typedef unsigned int  WORD;
typedef unsigned long DWORD;
#define PDI_BUS_SHIFT        8
#define PDI_BUS_SIZE         8
#define PDI_BUS_MAX          0xFF
#define PDI_BUS_MASK         0xFF00
#define PDI_DEVICE_SHIFT     3
#define PDI_DEVICE_SIZE      5
#define PDI_DEVICE_MAX       0x1F
#define PDI_DEVICE_MASK      0x00F8
#define PDI_FUNCTION_SHIFT   0
#define PDI_FUNCTION_SIZE    3
#define PDI_FUNCTION_MAX     0x7
#define PDI_FUNCTION_MASK    0x0007
#define MK_PDI(bus,dev,func) (WORD)((bus&PDI_BUS_MAX)<<PDI_BUS_SHIFT | (dev&PDI_DEVICE_MAX)<<PDI_DEVICE_SHIFT | (func&PDI_FUNCTION_MAX) )
/* PCI配置空间寄存器 */
#define PCI_CONFIG_ADDRESS   0xCF8
#define PCI_CONFIG_DATA      0xCFC
/* 填充PCI_CONFIG_ADDRESS */
#define MK_PCICFGADDR(bus,dev,func) (DWORD)(0x80000000L | (DWORD)MK_PDI(bus,dev,func) << 8)
/* 读取配置空间需要的函数 */
unsigned short  pciConfigReadWord(unsigned char bus, unsigned char slot, unsigned char func, unsigned char offset);
unsigned short  getVendorID(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getDeviceID(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getClassId(unsigned short bus, unsigned short device, unsigned short function);
unsigned short  getSubClassId(unsigned short bus, unsigned short device, unsigned short function);
/* 以上函数的实现 */
unsigned short  pciConfigReadWord(unsigned char bus, unsigned char slot, unsigned char func, unsigned char offset)
{
    unsigned int address;
    unsigned int lbus  = (unsigned int)bus;
    unsigned int lslot = (unsigned int)slot;
    unsigned int lfunc = (unsigned int)func;
    unsigned short tmp = 0;
 
    // Create configuration address as per Figure 1
    address = (unsigned int)((lbus << 16) | (lslot << 11) |
              (lfunc << 8) | (offset & 0xFC) | ((unsigned int)0x80000000));
 
    // Write out the address
    outl(0xCF8, address);
    // Read in the data
    // (offset & 2) * 8) = 0 will choose the first word of the 32-bit register
    tmp = (unsigned short)((inl(0xCFC) >> ((offset & 2) * 8)) & 0xFFFF);	
    return tmp;
}
unsigned short getVendorID(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0);
        return r0;
}

unsigned short getDeviceID(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,2);
        return r0;
}

unsigned short getClassId(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0xA);
        return (r0 & ~0x00FF) >> 8;
}

unsigned short getSubClassId(unsigned short bus, unsigned short device, unsigned short function)
{
        unsigned int r0 = pciConfigReadWord(bus,device,function,0xA);
        return (r0 & ~0xFF00);
}
int main(void)
{
    int bus, dev, func;
    int i;
    unsigned int dwAddr;
    unsigned int dwData;
    unsigned int tmpData;
	char s[256];
    FILE* hF;
    char szFile[0x10];
    printf("\n");
    printf("Bus#\tDevice#\tFunc#\tVendor\t        Device\tClass\tIRQ\tIntPin\n");
    /* 枚举PCI设备 */	
    for(bus = 0; bus <= PDI_BUS_MAX; ++bus)
    {
        for(dev = 0; dev <= PDI_DEVICE_MAX; ++dev)
        {
            for(func = 0; func <= PDI_FUNCTION_MAX; ++func)
            {
                /* 计算地址 */
                dwAddr = MK_PCICFGADDR(bus, dev, func);
				/* 得到ClassID */
				tmpData = getClassId(bus,dev,func);								
				if ((unsigned int)tmpData==0x01){						
                /* 获取厂商ID */  	
                outl(PCI_CONFIG_ADDRESS, dwAddr);
                dwData = inl(PCI_CONFIG_DATA);                	
                /* 判断设备是否存在。FFFFh是非法厂商ID */
                if ((unsigned int)dwData != 0xFFFFFFFF)
                {
                    /* bus/dev/func */
                    printf("%2.2X\t%2.2X\t%1X\t", bus, dev, func);
                    /* Vendor/Device */
                    printf("%4.4X\t%4.4X\t", (unsigned int)dwData, dwData>>16);
                    /* Class Code */
                    outl(PCI_CONFIG_ADDRESS, dwAddr | 0x8);
                    dwData = inl(PCI_CONFIG_DATA);
                    printf("%6.6lX\t", dwData>>8);	                                 						
                    /* IRQ/intPin */
                    {
						outl(PCI_CONFIG_ADDRESS, dwAddr | 0x3C);
                        dwData = inl(PCI_CONFIG_DATA);
                        printf("%d\t", (unsigned char)dwData);
                        printf("%d", (unsigned char)(dwData>>8));
                        printf("\n");
                    /* 写文件 */
					    sprintf(szFile, "PCI%2.2X%2.2X%X.bin", bus, dev, func);
                        hF = fopen(szFile, "wb");
                        if (hF != NULL)
						{
                        /* 256字节的PCI配置空间 */
                        //for (i = 0; i < 0x100; i += 4)
						for (i=0; i< 0x100; i += 4)	
                        {
                            /* Read */
                            outl(PCI_CONFIG_ADDRESS, dwAddr | i);
                            dwData = inl(PCI_CONFIG_DATA);								
                            /* Write */
                            fwrite(&dwData, sizeof(dwData), 1, hF);
                        }
                        fclose(hF);
						}
					}
                    }
                }
            }
        }
    }
    return 0;
}