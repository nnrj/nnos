#!/bin/bash
cp -rf ./ini/Makefile_linux.mak ./Makefile
make run
